def funcionPaquete():
    print("Hola, soy una funcion de un paquete")